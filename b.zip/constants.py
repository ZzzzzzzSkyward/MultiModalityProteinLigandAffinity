AMINO_ACID_AMOUNT = 29
AMINO_EMBEDDING_SIZE = 256
GRU_SIZE = 256
DATA_DIR = 'data_processed/'
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
