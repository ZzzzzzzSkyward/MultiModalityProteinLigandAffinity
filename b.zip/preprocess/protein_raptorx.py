'''
curl --form jobname=contact_job --form email=1900011733@pku.edu.cn --form sequences=ENIEVHMLNEVIEFHL http://raptorx2.uchicago.edu/ContactMap/curl/

'''
